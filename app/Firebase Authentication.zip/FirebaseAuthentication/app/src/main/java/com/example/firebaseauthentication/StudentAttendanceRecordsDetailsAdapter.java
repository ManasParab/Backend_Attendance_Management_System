package com.example.firebaseauthentication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class StudentAttendanceRecordsDetailsAdapter extends RecyclerView.Adapter<StudentAttendanceRecordsDetailsAdapter.AttendanceRecordViewHolder> {

    private List<Object> attendanceRecords;
    private final Context context;
    private final String date;

    public StudentAttendanceRecordsDetailsAdapter(List<Object> attendanceRecords, Context context, String date) {
        this.attendanceRecords = attendanceRecords;
        this.context = context;
        this.date = date;
    }

    @NonNull
    @Override
    public AttendanceRecordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_student_record_details, parent, false);
        return new AttendanceRecordViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AttendanceRecordViewHolder holder, int position) {
        Object attendanceRecord = attendanceRecords.get(position);
        // Splitting the attendanceRecord into date and time components
        String[] parts = attendanceRecord.toString().split(" ");
        String date = parts[0]; // Extracting the date part
        String time = parts[1]; // Extracting the time part
        String time2 = parts[2];

        String Date = "Date : " + date;
        String Time = "Time : " + time + " " + time2;

        // Bind data to views
        holder.textViewDate.setText(Date); // Display date in textViewDate
        holder.textViewTime.setText(Time); // Display time in textViewTime
    }


    @Override
    public int getItemCount() {
        return attendanceRecords.size();
    }

    static class AttendanceRecordViewHolder extends RecyclerView.ViewHolder {
        TextView textViewDate;
        TextView textViewTime;

        AttendanceRecordViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewDate = itemView.findViewById(R.id.tvDate);
            textViewTime = itemView.findViewById(R.id.tvTime);
        }
    }
}
