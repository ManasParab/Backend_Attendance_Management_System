package com.example.firebaseauthentication;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class TeacherAttendanceRecordsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AttendanceRecordsAdapter adapter;
    private List<DocumentSnapshot> attendanceRecords;

    private String joinCode; // Moved declaration here

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_attendance_records);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        attendanceRecords = new ArrayList<>();
        joinCode = getIntent().getStringExtra("joinCode");

        // Initialize the adapter here
        adapter = new AttendanceRecordsAdapter(attendanceRecords, joinCode, this);
        recyclerView.setAdapter(adapter);

        // Check if joinCode is not null
        if (joinCode != null && !joinCode.isEmpty()) {
            // Fetch attendance records from Firestore and listen for real-time updates
            FirebaseFirestore.getInstance()
                    .collection("classes")
                    .document(joinCode)
                    .collection("attendance_records")
                    .addSnapshotListener((queryDocumentSnapshots, e) -> {
                        if (e != null) {
                            // Error occurred, show error message
                            Toast.makeText(TeacherAttendanceRecordsActivity.this, "Failed to fetch attendance records: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            return;
                        }

                        if (queryDocumentSnapshots != null) {
                            // Clear the existing list and add new data
                            attendanceRecords.clear();
                            attendanceRecords.addAll(queryDocumentSnapshots.getDocuments());
                            // Notify adapter of data set change
                            adapter.notifyDataSetChanged();
                        }
                    });
        } else {
            Toast.makeText(TeacherAttendanceRecordsActivity.this, "Join code not found", Toast.LENGTH_SHORT).show();
        }
    }


}
