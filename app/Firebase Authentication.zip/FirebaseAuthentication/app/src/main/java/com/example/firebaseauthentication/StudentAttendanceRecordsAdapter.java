package com.example.firebaseauthentication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.List;

public class StudentAttendanceRecordsAdapter extends RecyclerView.Adapter<StudentAttendanceRecordsAdapter.AttendanceRecordViewHolder> {

    private final List<DocumentSnapshot> attendanceRecords;
    private final String joinCode, userName;

    private final Context context; // Add context variable

    public StudentAttendanceRecordsAdapter(List<DocumentSnapshot> attendanceRecords, String joinCode, Context context, String userName) {
        this.attendanceRecords = attendanceRecords;
        this.joinCode = joinCode;
        this.context = context; // Initialize context
        this.userName = userName;
    }

    @NonNull
    @Override
    public AttendanceRecordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_classmonthyear, parent, false);
        return new AttendanceRecordViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AttendanceRecordViewHolder holder, int position) {
        DocumentSnapshot record = attendanceRecords.get(position);
        // Bind data to views
        String monthYear = record.getId();
        holder.monthYearTextView.setText(monthYear);
        // Get classes conducted and bind to the corresponding TextView
        Long classesConducted = record.getLong("classesConducted");
        if (classesConducted != null) {
            holder.classesConductedTextView.setText("Classes Conducted: " + classesConducted);
        }
        // Hide the deleteCheckbox
        holder.deleteCheckbox.setVisibility(View.GONE);
        holder.itemView.setOnClickListener(v -> {
            // Handle item click to open ClassDetailsActivity
            openClassDetailsActivity(monthYear, joinCode, userName, String.valueOf(classesConducted)); // Pass both monthYear and joinCode
        });
    }

    private void openClassDetailsActivity(String monthYear, String joinCode, String userName, String classesConducted) {
        // Start ClassDetailsActivity and pass both monthYear and joinCode
        Intent intent = new Intent(context, StudentAttendanceRecordsDetailsActivity.class);
        intent.putExtra("monthYear", monthYear);
        intent.putExtra("joinCode", joinCode); // Add joinCode to Intent extras
        intent.putExtra("userName", userName);
        intent.putExtra("classesConducted", classesConducted);
        context.startActivity(intent);
    }

    @Override
    public int getItemCount() {
        return attendanceRecords.size();
    }

    static class AttendanceRecordViewHolder extends RecyclerView.ViewHolder {
        TextView monthYearTextView;
        TextView classesConductedTextView;
        // Add the deleteCheckbox here
        View deleteCheckbox;

        AttendanceRecordViewHolder(@NonNull View itemView) {
            super(itemView);
            monthYearTextView = itemView.findViewById(R.id.MonthYear);
            classesConductedTextView = itemView.findViewById(R.id.classesConducted);
            deleteCheckbox = itemView.findViewById(R.id.deleteCheckbox);
        }
    }
}
