package com.example.firebaseauthentication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SubCollectionRecordsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private SubCollectionRecordsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_collection_records);

        recyclerView = findViewById(R.id.recyclerViewSubCollectionRecords);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Retrieve additional information from intent
        String documentId = getIntent().getStringExtra("documentId");
        String joinCode = getIntent().getStringExtra("joinCode");
        String monthYear = getIntent().getStringExtra("monthYear");
        String selectedDate = getIntent().getStringExtra("selectedDate");

        // Fetch document data from Firestore
        FirebaseFirestore.getInstance()
                .collection("classes")
                .document(joinCode) // Assuming joinCode is the document ID
                .collection("attendance_records")
                .document(monthYear)
                .collection(selectedDate) // Assuming selectedDate is the document ID
                .document(documentId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    Map<String, Object> fieldsMap = documentSnapshot.getData();
                    if (fieldsMap != null) {
                        List<Map.Entry<String, Object>> fieldsList = new ArrayList<>(fieldsMap.entrySet());
                        adapter = new SubCollectionRecordsAdapter(fieldsList);
                        recyclerView.setAdapter(adapter);
                    }
                })
                .addOnFailureListener(e -> {
                    // Handle failure
                });
    }
}