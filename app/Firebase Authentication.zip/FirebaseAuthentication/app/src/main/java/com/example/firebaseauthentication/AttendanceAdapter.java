package com.example.firebaseauthentication;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AttendanceAdapter extends RecyclerView.Adapter<AttendanceAdapter.AttendanceViewHolder> {

    private Context context;
    private List<Map<String, Object>> attendanceList;
    private SparseBooleanArray selectedItems;

    private String joinCode; // Added joinCode field

    public AttendanceAdapter(Context context, List<Map<String, Object>> attendanceList, String joinCode) {
        this.context = context;
        this.attendanceList = attendanceList;
        this.selectedItems = new SparseBooleanArray();
        this.joinCode = joinCode; // Set joinCode

        // Initialize selectedItems with all positions set to true
        for (int i = 0; i < attendanceList.size(); i++) {
            selectedItems.put(i, true);
        }
    }

    @NonNull
    @Override
    public AttendanceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_attendance_record, parent, false);
        return new AttendanceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AttendanceViewHolder holder, int position) {
        Map<String, Object> attendanceRecord = attendanceList.get(position);
        String attendeeName = (String) attendanceRecord.get("attendeeName");
        String markingTime = (String) attendanceRecord.get("markingTime");


        holder.nameTextView.setText(attendeeName);
        holder.dateTimeTextView.setText("Marked at: " + markingTime);

        // Set the checkbox state based on selectedItems
        boolean isSelected = selectedItems.get(position, false);
        holder.checkBox.setChecked(isSelected);

        // Set a click listener to handle checkbox selection
        holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Update selectedItems to reflect checkbox state
            selectedItems.put(position, isChecked);
            if (!isChecked) {
                // If checkbox is unchecked, remove the corresponding document from temp_records
                removeDocumentFromTempRecords(attendanceRecord);
            }
        });
    }

    // Method to remove the document from temp_records
    private void removeDocumentFromTempRecords(Map<String, Object> attendanceRecord) {
        FirebaseFirestore.getInstance()
                .collection("classes")
                .document(joinCode)
                .collection("attendance_records")
                .document(new SubjectDetailsActivity().getCurrentMonthYear())
                .collection("temp_records")
                .document((String) attendanceRecord.get("attendeeName"))
                .delete()
                .addOnSuccessListener(aVoid -> {
                    // Document removed successfully
                    Toast.makeText(context, "Document removed from temp_records", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    // Error occurred while removing document
                    Toast.makeText(context, "Failed to remove document from temp_records", Toast.LENGTH_SHORT).show();
                    Log.e("AttendanceAdapter", "Error removing document from temp_records", e);
                });
    }


    @Override
    public int getItemCount() {
        return attendanceList.size();
    }

    // Method to get the selected items
    public List<Map<String, Object>> getSelectedItems() {
        List<Map<String, Object>> selectedItemsList = new ArrayList<>();
        for (int i = 0; i < attendanceList.size(); i++) {
            if (selectedItems.get(i)) {
                selectedItemsList.add(attendanceList.get(i));
            }
        }
        return selectedItemsList;
    }

    // Method to set the selection state of an item
    public void setSelected(int position, boolean isSelected) {
        selectedItems.put(position, isSelected);
    }

    // Method to check if an item is selected
    public boolean isSelected(int position) {
        return selectedItems.get(position, false);
    }

    public class AttendanceViewHolder extends RecyclerView.ViewHolder {

        TextView nameTextView, dateTimeTextView;
        CheckBox checkBox;

        public AttendanceViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            dateTimeTextView = itemView.findViewById(R.id.dateTimeTextView);
            checkBox = itemView.findViewById(R.id.checkBox);
        }
    }
}
