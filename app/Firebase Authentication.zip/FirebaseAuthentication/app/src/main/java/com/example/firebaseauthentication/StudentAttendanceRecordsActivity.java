package com.example.firebaseauthentication;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class StudentAttendanceRecordsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private StudentAttendanceRecordsAdapter adapter;
    private List<DocumentSnapshot> attendanceRecords;
    String userId, userName, joinCode, subjectName;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_attendance_records);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Retrieve user ID and name from intent extras
        userId = getIntent().getStringExtra("userId");
        userName = getIntent().getStringExtra("userName");
        joinCode = getIntent().getStringExtra("joinCode");
        subjectName = getIntent().getStringExtra("subjectName");

        // Display user ID and name
        Toast.makeText(this, "User Name: " + userName, Toast.LENGTH_SHORT).show();
        Toast.makeText(this, "User ID: " + userId, Toast.LENGTH_SHORT).show();
        Toast.makeText(this, "Join Code: " + joinCode, Toast.LENGTH_SHORT).show();
        Toast.makeText(this, "Subject Name: " + subjectName, Toast.LENGTH_SHORT).show();

        // Initialize attendanceRecords list
        attendanceRecords = new ArrayList<>();

        // Fetch attendance records from Firestore
        FirebaseFirestore.getInstance()
                .collection("classes")
                .document(joinCode)
                .collection("attendance_records")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    for (DocumentSnapshot document : querySnapshot.getDocuments()) {
                        // Process each document within the attendance_records collection
                        attendanceRecords.add(document);
                    }
                    // Set up RecyclerView with adapter
                    adapter = new StudentAttendanceRecordsAdapter(attendanceRecords, joinCode, this, userName);
                    recyclerView.setAdapter(adapter);
                })
                .addOnFailureListener(e -> {
                    // Failed to fetch attendance records
                    Toast.makeText(StudentAttendanceRecordsActivity.this, "Failed to fetch attendance records", Toast.LENGTH_SHORT).show();
                });
    }
}
