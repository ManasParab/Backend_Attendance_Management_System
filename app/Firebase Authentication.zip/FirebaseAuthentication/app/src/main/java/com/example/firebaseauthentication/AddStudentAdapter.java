package com.example.firebaseauthentication;

import android.content.Context;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AddStudentAdapter extends RecyclerView.Adapter<AddStudentAdapter.StudentViewHolder> {

    private List<String> studentsList;
    private SparseBooleanArray selectedItems;
    private Context context;

    public AddStudentAdapter(List<String> studentsList, Context context) {
        this.studentsList = studentsList;
        this.context = context;
        selectedItems = new SparseBooleanArray();
    }

    @NonNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_add_student, parent, false);
        return new StudentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentViewHolder holder, int position) {
        String studentName = studentsList.get(position);
        holder.textViewStudentName.setText(studentName);
        holder.checkBox.setChecked(selectedItems.get(position, false));
    }

    @Override
    public int getItemCount() {
        return studentsList.size();
    }

    public List<String> getSelectedStudents() {
        List<String> selectedStudents = new ArrayList<>();
        for (int i = 0; i < studentsList.size(); i++) {
            if (selectedItems.get(i)) {
                selectedStudents.add(studentsList.get(i));
            }
        }
        return selectedStudents;
    }

    class StudentViewHolder extends RecyclerView.ViewHolder {
        TextView textViewStudentName;
        CheckBox checkBox;

        StudentViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewStudentName = itemView.findViewById(R.id.textViewStudentName);
            checkBox = itemView.findViewById(R.id.addCheckbox);

            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    selectedItems.put(getAdapterPosition(), isChecked);
                }
            });
        }
    }
}
