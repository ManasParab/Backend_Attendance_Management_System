package com.example.firebaseauthentication;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;
import java.util.List;

public class StudentsEnrolledActivity extends AppCompatActivity {

    private RecyclerView recyclerViewStudents;
    private StudentsAdapter adapter;
    private List<String> studentsList;
    private FirebaseFirestore db;
    private String joinCode; // Added to store the join code

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_students_enrolled);

        // Retrieve the join code from the intent extras
        joinCode = getIntent().getStringExtra("joinCode");

        recyclerViewStudents = findViewById(R.id.recyclerViewStudents);
        recyclerViewStudents.setLayoutManager(new LinearLayoutManager(this));

        studentsList = new ArrayList<>();
        adapter = new StudentsAdapter(studentsList);
        recyclerViewStudents.setAdapter(adapter);

        db = FirebaseFirestore.getInstance();

        fetchStudents();
    }

    private void fetchStudents() {
        // Use the retrieved joinCode to fetch students
        db.collection("classes").document(joinCode).collection("students")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        for (DocumentSnapshot document : task.getResult()) {
                            String studentName = document.getString("name");
                            studentsList.add(studentName);
                        }
                        adapter.notifyDataSetChanged();
                    } else {
                        // Handle errors
                    }
                });
    }
}
