package com.example.firebaseauthentication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Map;

public class SubCollectionRecordsAdapter extends RecyclerView.Adapter<SubCollectionRecordsAdapter.FieldViewHolder> {

    private final List<Map.Entry<String, Object>> fieldsList;

    public SubCollectionRecordsAdapter(List<Map.Entry<String, Object>> fieldsList) {
        this.fieldsList = fieldsList;
    }

    @NonNull
    @Override
    public FieldViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_field, parent, false);
        return new FieldViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FieldViewHolder holder, int position) {
        Map.Entry<String, Object> fieldEntry = fieldsList.get(position);
        String fieldName = fieldEntry.getKey();

        holder.fieldNameTextView.setText(fieldName);
    }

    @Override
    public int getItemCount() {
        return fieldsList.size();
    }

    static class FieldViewHolder extends RecyclerView.ViewHolder {
        TextView fieldNameTextView;

        FieldViewHolder(@NonNull View itemView) {
            super(itemView);
            fieldNameTextView = itemView.findViewById(R.id.fieldName);
        }
    }
}
