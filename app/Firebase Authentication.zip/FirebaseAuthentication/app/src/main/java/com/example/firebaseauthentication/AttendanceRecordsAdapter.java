package com.example.firebaseauthentication;

import android.content.Context;
import android.content.Intent;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AttendanceRecordsAdapter extends RecyclerView.Adapter<AttendanceRecordsAdapter.AttendanceRecordViewHolder> {

    private final List<DocumentSnapshot> attendanceRecords;
    private final SparseBooleanArray checkedItems; // SparseBooleanArray to store checkbox states
    private final String joinCode;
    private final Context context; // Add context variable

    public AttendanceRecordsAdapter(List<DocumentSnapshot> attendanceRecords, String joinCode, Context context) {
        this.attendanceRecords = attendanceRecords;
        this.joinCode = joinCode;
        this.context = context; // Initialize context
        checkedItems = new SparseBooleanArray();
    }

    @NonNull
    @Override
    public AttendanceRecordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_classmonthyear, parent, false);
        return new AttendanceRecordViewHolder(view);
    }

    // AttendanceRecordsAdapter.java
    @Override
    public void onBindViewHolder(@NonNull AttendanceRecordViewHolder holder, int position) {
        DocumentSnapshot record = attendanceRecords.get(position);
        // Bind data to views
        String monthYear = record.getId();
        holder.monthYearTextView.setText(monthYear);
        // Get classes conducted and bind to the corresponding TextView
        Long classesConducted = record.getLong("classesConducted");
        if (classesConducted != null) {
            holder.classesConductedTextView.setText("Classes Conducted: " + classesConducted);
        }
        // Set checkbox state based on SparseBooleanArray
        holder.checkBox.setChecked(checkedItems.get(position));
        holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Update the SparseBooleanArray with the checkbox state
            checkedItems.put(position, isChecked);
            // Call deleteRecord method if checkbox is checked
            if (isChecked) {
                deleteRecord(position);
            }
        });
        holder.itemView.setOnClickListener(v -> {
            // Handle item click to open ClassDetailsActivity
            openClassDetailsActivity(monthYear, joinCode); // Pass both monthYear and joinCode
        });
    }

    private void openClassDetailsActivity(String monthYear, String joinCode) {
        // Start ClassDetailsActivity and pass both monthYear and joinCode
        Intent intent = new Intent(context, ClassDetailsActivity.class);
        intent.putExtra("monthYear", monthYear);
        intent.putExtra("joinCode", joinCode); // Add joinCode to Intent extras
        context.startActivity(intent);
    }


    @Override
    public int getItemCount() {
        return attendanceRecords.size();
    }

    // Method to delete a record
    // Method to delete a record with confirmation
    private void deleteRecord(int position) {
        DocumentSnapshot recordToDelete = attendanceRecords.get(position);
        String monthYear = recordToDelete.getId();

        // Create a confirmation dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Confirm Deletion");
        builder.setMessage("Are you sure you want to delete this record?");
        builder.setPositiveButton("Yes", (dialog, which) -> {
            // User confirmed deletion, proceed with deletion
            performDeletion(monthYear, position);
        });
        builder.setNegativeButton("No", null);
        builder.show();
    }

    // Method to perform deletion of records
    // Method to perform deletion of records
    // Method to perform deletion of records
    private void performDeletion(String monthYear, int position) {
        // Get the last day of the month
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        SimpleDateFormat monthYearFormat = new SimpleDateFormat("MMM_yyyy", Locale.getDefault());
        Date monthYearDate;
        try {
            monthYearDate = monthYearFormat.parse(monthYear);
        } catch (ParseException e) {
            e.printStackTrace();
            return; // Return if parsing fails
        }

        calendar.setTime(monthYearDate); // Set calendar to the parsed date
        int lastDayOfMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        // Loop through each day of the month
        calendar.set(Calendar.DAY_OF_MONTH, 1); // Set to the first day of the month
        for (int day = 1; day <= lastDayOfMonth; day++) {
            calendar.set(Calendar.DAY_OF_MONTH, day); // Set the current day of the month

            // Get the date in "dd-MM-yyyy" format
            String date = dateFormat.format(calendar.getTime());

            // Construct reference to the collection for the current date within the month and year
            CollectionReference monthYearRef = FirebaseFirestore.getInstance()
                    .collection("classes")
                    .document(joinCode)
                    .collection("attendance_records")
                    .document(monthYear)
                    .collection(date);

            // Check if documents exist under the current date
            monthYearRef.get().addOnSuccessListener(querySnapshot -> {
                if (!querySnapshot.isEmpty()) {
                    // Iterate through documents and delete them
                    for (DocumentSnapshot document : querySnapshot.getDocuments()) {
                        String documentId = document.getId();
                        // Construct reference to the document to be deleted
                        DocumentReference documentRef = monthYearRef.document(documentId);
                        // Delete the document
                        documentRef.delete().addOnSuccessListener(aVoid -> {
                            // Document deleted successfully
                            Toast.makeText(context, "Document deleted: " + documentId + " for date: " + date, Toast.LENGTH_SHORT).show();
                        }).addOnFailureListener(e -> {
                            // Failed to delete document
                            Toast.makeText(context, "Failed to delete document: " + documentId + " for date: " + date, Toast.LENGTH_SHORT).show();
                        });
                    }
                }
            }).addOnFailureListener(e -> {
                Toast.makeText(context, "Failed to retrieve records: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        }

// After deleting all documents, delete the monthYear document
        FirebaseFirestore.getInstance()
                .collection("classes")
                .document(joinCode)
                .collection("attendance_records")
                .document(monthYear)
                .delete()
                .addOnSuccessListener(aVoid -> {
                    // MonthYear document deleted successfully
                    Toast.makeText(context, "MonthYear document deleted: " + monthYear, Toast.LENGTH_SHORT).show();
                }).addOnFailureListener(e -> {
                    // Failed to delete monthYear document
                    Toast.makeText(context, "Failed to delete MonthYear document: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });

    }


    static class AttendanceRecordViewHolder extends RecyclerView.ViewHolder {
        TextView monthYearTextView;
        TextView classesConductedTextView;
        CheckBox checkBox;

        AttendanceRecordViewHolder(@NonNull View itemView) {
            super(itemView);
            monthYearTextView = itemView.findViewById(R.id.MonthYear);
            classesConductedTextView = itemView.findViewById(R.id.classesConducted);
            checkBox = itemView.findViewById(R.id.deleteCheckbox);
        }
    }

}
