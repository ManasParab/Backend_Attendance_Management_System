package com.example.firebaseauthentication;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StudentAttendanceRecordsDetailsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private StudentAttendanceRecordsDetailsAdapter adapter;
    private List<Object> attendanceRecordsList;
    private List<Object> arrayField;
    private List<DocumentSnapshot> attendanceRecords;
    private String joinCode, monthYear, userName, classesConducted;

    TextView attendanceCount;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_attendance_records_details);


        attendanceCount = findViewById(R.id.attendanceCount);
        recyclerView = findViewById(R.id.recyclerViewDetails);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        joinCode = getIntent().getStringExtra("joinCode");
        monthYear = getIntent().getStringExtra("monthYear");
        userName = getIntent().getStringExtra("userName");
        classesConducted = getIntent().getStringExtra("classesConducted");

        attendanceRecordsList = new ArrayList<>(); // Initialize the list

        FirebaseFirestore.getInstance()
                .collection("classes")
                .document(joinCode)
                .collection("attendance_records")
                .document(monthYear)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        for (int day = 1; day <= getLastDayOfMonth(monthYear); day++) {
                            String date = String.format("%02d-%02d-%04d", day, getMonth(monthYear), getYear(monthYear));

                            FirebaseFirestore.getInstance()
                                    .collection("classes")
                                    .document(joinCode)
                                    .collection("attendance_records")
                                    .document(monthYear)
                                    .collection(date)
                                    .whereArrayContains(userName, userName)
                                    .get()
                                    .addOnSuccessListener(queryDocumentSnapshots -> {
                                        for (DocumentSnapshot document : queryDocumentSnapshots) {
                                            List<Object> arrayField = (List<Object>) document.get(userName);
                                            if (arrayField != null && !arrayField.isEmpty()) {
                                                Object firstElement = arrayField.get(0);
                                                // Add each attendance record to the list
                                                attendanceRecordsList.add(firstElement);
                                            } else {
                                                Toast.makeText(this, "Array field is empty or does not contain enough elements", Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                        Collections.reverse(attendanceRecordsList);
                                        // Set up the adapter after fetching all records
                                        adapter = new StudentAttendanceRecordsDetailsAdapter(attendanceRecordsList, this, date);
                                        recyclerView.setAdapter(adapter);
                                        String classPresent = "Classes Attended : " + attendanceRecordsList.size() + "/" + classesConducted;
                                        attendanceCount.setText(classPresent);
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(this, "Failed to fetch attendance records for a specific date", Toast.LENGTH_SHORT).show();
                                    });
                        }
                    } else {
                        // Handle the case where the document for the specified monthYear does not exist
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to fetch the monthYear document", Toast.LENGTH_SHORT).show();
                });
    }

    // Helper method to get the last day of the month
    private int getLastDayOfMonth(String monthYear) {
        int month = getMonth(monthYear);
        int year = getYear(monthYear);
        return month == 2 ? (year % 4 == 0 ? 29 : 28) : (month == 4 || month == 6 || month == 9 || month == 11 ? 30 : 31);
    }

    // Helper method to extract the month from the monthYear string
    private int getMonth(String monthYear) {
        String[] parts = monthYear.split("_");
        String monthString = parts[0];
        switch (monthString) {
            case "Jan":
                return 1;
            case "Feb":
                return 2;
            case "Mar":
                return 3;
            case "Apr":
                return 4;
            case "May":
                return 5;
            case "Jun":
                return 6;
            case "Jul":
                return 7;
            case "Aug":
                return 8;
            case "Sep":
                return 9;
            case "Oct":
                return 10;
            case "Nov":
                return 11;
            case "Dec":
                return 12;
            default:
                return -1; // Invalid month string
        }
    }

    // Helper method to extract the year from the monthYear string
    private int getYear(String monthYear) {
        String[] parts = monthYear.split("_");
        return Integer.parseInt(parts[1]); // Assuming year is in the format "MM_YYYY"
    }

}
