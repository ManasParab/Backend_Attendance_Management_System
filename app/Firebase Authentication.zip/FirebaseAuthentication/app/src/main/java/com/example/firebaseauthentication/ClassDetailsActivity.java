package com.example.firebaseauthentication;

import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class ClassDetailsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private SubCollectionsAdapter adapter;
    private CalendarView calendarView;
    private String monthYear, joinCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_details);

        // Retrieve values from intent extras
        monthYear = getIntent().getStringExtra("monthYear");
        joinCode = getIntent().getStringExtra("joinCode");

        // Toast to check the values of monthYear and joinCode
        Toast.makeText(this, "MonthYear: " + monthYear + ", JoinCode: " + joinCode, Toast.LENGTH_SHORT).show();

        recyclerView = findViewById(R.id.recyclerViewSubCollections);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);

        calendarView = findViewById(R.id.calendarView);

        // Set onDateChangeListener with a custom implementation
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // Handle date selection within this function
            String selectedDate = formatDate(dayOfMonth, month + 1, year); // Month is zero-based
            Toast.makeText(ClassDetailsActivity.this, "Selected Date: " + selectedDate, Toast.LENGTH_SHORT).show();
            fetchDataForSelectedDate(selectedDate, joinCode, monthYear);
        });

        // Extract month and year froms the monthYear variable
        String[] parts = monthYear.split("_");
        int month = getMonthFromString(parts[0]); // Convert month string to integer
        int year = Integer.parseInt(parts[1]);

        // Set the calendar to display the specified month and year
        calendarView.setDate(getTimeInMillis(month, year));

        // Fetch sub-collections data from Firestore for the current date initially
        fetchDataForSelectedDate(getCurrentDate(), joinCode, monthYear);
    }

    // Helper method to get time in milliseconds for the specified month and year
    private long getTimeInMillis(int month, int year) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        return calendar.getTimeInMillis();
    }

    // Helper method to convert month string to integer
    private int getMonthFromString(String monthStr) {
        SimpleDateFormat monthDate = new SimpleDateFormat("MMM", Locale.getDefault());
        Calendar calendar = Calendar.getInstance();
        try {
            calendar.setTime(monthDate.parse(monthStr));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return calendar.get(Calendar.MONTH);
    }

    private void fetchDataForSelectedDate(String selectedDate, String joinCode, String monthYear) {
        // Fetch data for the selected date from Firestore
        FirebaseFirestore.getInstance()
                .collection("classes")
                .document(joinCode)
                .collection("attendance_records")
                .document(monthYear)
                .collection(selectedDate) // Assuming sub-collections are named after dates
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<DocumentSnapshot> documents = queryDocumentSnapshots.getDocuments();
                    if (!documents.isEmpty()) {
                        // Documents found for the selected date
                        List<String> documentNames = new ArrayList<>();
                        for (DocumentSnapshot snapshot : documents) {
                            // Add the document ID to the list
                            documentNames.add(snapshot.getId());
                        }
                        // Toast the document names one after the other
                        for (String documentName : documentNames) {
                            Toast.makeText(this, "Document Name: " + documentName, Toast.LENGTH_SHORT).show();
                        }
                        // Update the adapter with the new data
                        // Inside fetchDataForSelectedDate method
                        adapter = new SubCollectionsAdapter(this, documents, joinCode, monthYear, selectedDate);
                        recyclerView.setAdapter(adapter);

                    } else {
                        // No documents found for the selected date
                        Toast.makeText(this, "No documents found for the selected date", Toast.LENGTH_SHORT).show();
                        recyclerView.setAdapter(null); // Clear the RecyclerView
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to fetch data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    recyclerView.setAdapter(null); // Clear the RecyclerView
                });
    }


    private String getCurrentDate() {
        // Get current date and format it
        Calendar calendar = Calendar.getInstance();
        return formatDate(calendar.get(Calendar.DAY_OF_MONTH), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.YEAR));
    }

    // Helper method to format date
    private String formatDate(int day, int month, int year) {
        return String.format(Locale.getDefault(), "%02d-%02d-%04d", day, month, year);
    }
}