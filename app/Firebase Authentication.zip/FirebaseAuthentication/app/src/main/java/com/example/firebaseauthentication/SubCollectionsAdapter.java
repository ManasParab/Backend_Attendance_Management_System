package com.example.firebaseauthentication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;

import java.util.List;

public class SubCollectionsAdapter extends RecyclerView.Adapter<SubCollectionsAdapter.SubCollectionViewHolder> {

    private final List<DocumentSnapshot> subCollectionsData;
    private final Context context;
    private final String joinCode;
    private final String monthYear;
    private final String selectedDate;

    public SubCollectionsAdapter(Context context, List<DocumentSnapshot> subCollectionsData, String joinCode, String monthYear, String selectedDate) {
        this.context = context;
        this.subCollectionsData = subCollectionsData;
        this.joinCode = joinCode;
        this.monthYear = monthYear;
        this.selectedDate = selectedDate;
    }

    @NonNull
    @Override
    public SubCollectionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sub_collection, parent, false);
        return new SubCollectionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SubCollectionViewHolder holder, int position) {
        DocumentSnapshot subCollectionData = subCollectionsData.get(position);
        String documentName = subCollectionData.getId(); // Document ID
        int fieldCount = subCollectionData.getData() != null ? subCollectionData.getData().size() : 0;

        holder.nameTextView.setText(documentName);
        holder.fieldCountTextView.setText("Students : " + fieldCount);

        // Set click listener
        holder.itemView.setOnClickListener(v -> {
            // Open SubCollectionRecordsActivity with selected document ID and other details
            Intent intent = new Intent(context, SubCollectionRecordsActivity.class);
            intent.putExtra("documentId", documentName);
            intent.putExtra("joinCode", joinCode);
            intent.putExtra("monthYear", monthYear);
            intent.putExtra("selectedDate", selectedDate);
            context.startActivity(intent);
        });
    }


    @Override
    public int getItemCount() {
        return subCollectionsData.size();
    }

    static class SubCollectionViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView fieldCountTextView;

        SubCollectionViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialize TextViews
            nameTextView = itemView.findViewById(R.id.subCollectionName);
            fieldCountTextView = itemView.findViewById(R.id.classesConducted);
        }
    }
}
