package com.example.firebaseauthentication;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class SubjectDetailsActivity extends AppCompatActivity {

    MaterialButton chkStudentsButton, markAttendance, newAttendance, chkAttendance, myAttendance;
    private TextView tvSubjectName, tvJoiningCode;
    private String userRole, joinCode, subjectName; // Variable to store user's role

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subject_details);

        tvSubjectName = findViewById(R.id.tvSubjectName);
        tvJoiningCode = findViewById(R.id.tvJoiningCode);

        chkStudentsButton = findViewById(R.id.chkStudents);
        newAttendance = findViewById(R.id.newAttendance);
        markAttendance = findViewById(R.id.markAttendance);
        chkAttendance = findViewById(R.id.chkAttendance);
        myAttendance = findViewById(R.id.myAttendance);

        // Retrieve data from intent
        subjectName = getIntent().getStringExtra("subjectName");
        joinCode = getIntent().getStringExtra("joinCode");


        // Set data to views
        tvSubjectName.setText(subjectName);
        tvJoiningCode.setText(joinCode);

        // Fetch user's role from Firestore
        fetchUserRole();

        // Set click listener for newAttendance button
        // Set click listener for newAttendance button
        newAttendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show confirmation dialog before starting attendance
                showConfirmationDialog();
            }
        });


        // Method to show confirmation dialog before starting attendance
        markAttendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                markAttendance();
            }
        });

        // Inside onCreate() method of SubjectDetailsActivity.java

        chkAttendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start TeacherAttendanceRecordsActivity and pass the joinCode via intent
                Intent intent = new Intent(SubjectDetailsActivity.this, TeacherAttendanceRecordsActivity.class);
                intent.putExtra("joinCode", joinCode); // Pass the joinCode from the TextView
                startActivity(intent);
            }
        });


        // Set click listener for chkStudents button
        chkStudentsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start StudentsEnrolledActivity and pass the joinCode via intent
                Intent intent = new Intent(SubjectDetailsActivity.this, StudentsEnrolledActivity.class);
                intent.putExtra("joinCode", joinCode); // Pass the joinCode from the TextView
                startActivity(intent);
            }
        });

        myAttendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myAttendance();

            }
        });
    }

    private void fetchUserRole() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            FirebaseFirestore.getInstance().collection("users").document(user.getUid())
                    .get()
                    .addOnSuccessListener(this::onUserRoleSuccess)
                    .addOnFailureListener(e -> Toast.makeText(SubjectDetailsActivity.this, "Error fetching user data", Toast.LENGTH_SHORT).show());
        }
    }

    private void onUserRoleSuccess(DocumentSnapshot documentSnapshot) {
        if (documentSnapshot.exists()) {
            userRole = documentSnapshot.getString("role");
            updateUIForRole(userRole);
        }
    }

    private void updateUIForRole(String role) {

        if ("teacher".equals(role)) {
            newAttendance.setVisibility(View.VISIBLE);
            chkAttendance.setVisibility(View.VISIBLE);
            chkStudentsButton.setVisibility(View.VISIBLE);
        } else {
            markAttendance.setVisibility(View.VISIBLE);
            myAttendance.setVisibility(View.VISIBLE);
        }
    }

    String getCurrentMonthYear() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM_yyyy", Locale.getDefault());
        return dateFormat.format(calendar.getTime());
    }

    private String getCurrentDateTime() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a", Locale.getDefault());
        return dateFormat.format(calendar.getTime());
    }

    private void showConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirm Start Attendance");
        builder.setMessage("Are you sure you want to start attendance?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // User confirmed, start attendance
                startAttendance();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // User canceled, do nothing
            }
        });
        builder.show();
    }

    // Method to start attendance
    // Method to start attendance
    private void startAttendance() {
        // Update attendance value to true in Firestore
        FirebaseFirestore.getInstance()
                .collection("classes")
                .document(joinCode)
                .update("attendance", true)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(SubjectDetailsActivity.this, "Attendance marking ON", Toast.LENGTH_SHORT).show();
                    // Create intent to navigate to AttendanceManagementActivity
                    Intent intent = new Intent(SubjectDetailsActivity.this, AttendanceManagementActivity.class);
                    intent.putExtra("joinCode", joinCode); // Pass joinCode to the next activity
                    startActivity(intent); // Start the activity
                })
                .addOnFailureListener(e -> Toast.makeText(SubjectDetailsActivity.this, "Failed to mark attendance", Toast.LENGTH_SHORT).show());
    }


    // Method to create attendance records sub-collection
    private void createAttendanceRecords() {
        // Get current month and year
        String currentMonthYear = getCurrentMonthYear();

        // Get reference to the attendance records document
        DocumentReference attendanceDocRef = FirebaseFirestore.getInstance()
                .collection("classes")
                .document(joinCode)
                .collection("attendance_records")
                .document(currentMonthYear);

        // Check if the document already exists
        attendanceDocRef.get().addOnSuccessListener(documentSnapshot -> {
            if (!documentSnapshot.exists()) {
                // Document doesn't exist, create it with classesConducted initialized to 0
                Map<String, Object> data = new HashMap<>();
                data.put("classesConducted", 0);

                attendanceDocRef.set(data)
                        .addOnSuccessListener(aVoid -> {
                            // classesConducted created successfully
                        })
                        .addOnFailureListener(e -> {
                            // Failed to create classesConducted
                        });
            }
        }).addOnFailureListener(e -> {
            // Failed to check if the document exists
            Toast.makeText(SubjectDetailsActivity.this, "Failed to check attendance records", Toast.LENGTH_SHORT).show();
        });
    }


    // Method to mark attendance
    // Method to mark attendance
    private void markAttendance() {
        // Check if attendance marking is allowed
        FirebaseFirestore.getInstance()
                .collection("classes")
                .document(joinCode)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        boolean attendanceAllowed = documentSnapshot.getBoolean("attendance");
                        if (attendanceAllowed) {
                            // Fetch user's name from Firestore
                            FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                            if (currentUser != null) {
                                String userId = currentUser.getUid();
                                FirebaseFirestore.getInstance()
                                        .collection("users")
                                        .document(userId)
                                        .get()
                                        .addOnSuccessListener(userDocument -> {
                                            if (userDocument.exists()) {
                                                String userName = userDocument.getString("name");
                                                if (userName != null && !userName.isEmpty()) {
                                                    // Check if the document exists before creating it
                                                    FirebaseFirestore.getInstance()
                                                            .collection("classes")
                                                            .document(joinCode)
                                                            .collection("attendance_records")
                                                            .document(getCurrentMonthYear())
                                                            .collection("temp_records")
                                                            .document(userName)
                                                            .get()
                                                            .addOnSuccessListener(document -> {
                                                                if (!document.exists()) {
                                                                    // Document doesn't exist, create it
                                                                    String currentDateTime = getCurrentDateTime();
                                                                    Map<String, Object> attendanceData = new HashMap<>();
                                                                    attendanceData.put("Name", userName);
                                                                    attendanceData.put("markingTime", currentDateTime);
                                                                    FirebaseFirestore.getInstance()
                                                                            .collection("classes")
                                                                            .document(joinCode)
                                                                            .collection("attendance_records")
                                                                            .document(getCurrentMonthYear())
                                                                            .collection("temp_records")
                                                                            .document(userName)
                                                                            .set(attendanceData)
                                                                            .addOnSuccessListener(aVoid -> {
                                                                                Toast.makeText(SubjectDetailsActivity.this, "Attendance marked for " + userName, Toast.LENGTH_SHORT).show();
                                                                            })
                                                                            .addOnFailureListener(e -> {
                                                                                Toast.makeText(SubjectDetailsActivity.this, "Failed to mark attendance", Toast.LENGTH_SHORT).show();
                                                                            });
                                                                } else {
                                                                    // Document already exists, show a message or handle accordingly
                                                                    Toast.makeText(SubjectDetailsActivity.this, "Attendance already marked for " + userName, Toast.LENGTH_SHORT).show();
                                                                }
                                                            })
                                                            .addOnFailureListener(e -> {
                                                                // Failed to check if the document exists
                                                                Toast.makeText(SubjectDetailsActivity.this, "Failed to check attendance record", Toast.LENGTH_SHORT).show();
                                                            });
                                                } else {
                                                    Toast.makeText(SubjectDetailsActivity.this, "User name not found", Toast.LENGTH_SHORT).show();
                                                }
                                            } else {
                                                Toast.makeText(SubjectDetailsActivity.this, "User document not found", Toast.LENGTH_SHORT).show();
                                            }
                                        })
                                        .addOnFailureListener(e -> {
                                            Toast.makeText(SubjectDetailsActivity.this, "Failed to fetch user data", Toast.LENGTH_SHORT).show();
                                        });
                            } else {
                                Toast.makeText(SubjectDetailsActivity.this, "Current user not found", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(SubjectDetailsActivity.this, "Attendance marking is not allowed for this class", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(SubjectDetailsActivity.this, "Class document not found", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(SubjectDetailsActivity.this, "Failed to check attendance permission", Toast.LENGTH_SHORT).show();
                });
    }

    private void myAttendance() {
        // Check if the current user is authenticated
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            // Get user ID
            String userId = currentUser.getUid();

            // Fetch user's name from Firestore
            FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(userId)
                    .get()
                    .addOnSuccessListener(userDocument -> {
                        if (userDocument.exists()) {
                            String userName = userDocument.getString("name");
                            if (userName != null && !userName.isEmpty()) {
                                // Create intent to navigate to StudentAttendanceRecordsActivity
                                Intent intent = new Intent(SubjectDetailsActivity.this, StudentAttendanceRecordsActivity.class);

                                // Pass user ID and name as extras
                                intent.putExtra("userId", userId);
                                intent.putExtra("userName", userName);
                                intent.putExtra("joinCode", joinCode);
                                intent.putExtra("subjectName", subjectName);

                                // Start StudentAttendanceRecordsActivity
                                startActivity(intent);
                            } else {
                                Toast.makeText(SubjectDetailsActivity.this, "User name not found", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(SubjectDetailsActivity.this, "User document not found", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(SubjectDetailsActivity.this, "Failed to fetch user data", Toast.LENGTH_SHORT).show();
                    });
        } else {
            Toast.makeText(SubjectDetailsActivity.this, "Current user not found", Toast.LENGTH_SHORT).show();
        }
    }


}