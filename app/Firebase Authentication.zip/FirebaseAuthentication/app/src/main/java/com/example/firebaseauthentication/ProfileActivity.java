package com.example.firebaseauthentication;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {

    MaterialButton saveBtn, cancelBtn;
    private EditText dobEditText, emailEditText, nameEditText, phoneEditText, rollNumberEditText;
    private TextInputLayout rollNumberLayout;
    private String email;
    private String role;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        dobEditText = findViewById(R.id.dobEditText);
        emailEditText = findViewById(R.id.emailEditText);
        rollNumberEditText = findViewById(R.id.rollNumberEditText);
        rollNumberLayout = findViewById(R.id.rollNumberLayout);
        nameEditText = findViewById(R.id.nameEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        saveBtn = findViewById(R.id.saveBtn);
        cancelBtn = findViewById(R.id.cancelBtn);

        // Get the data passed from MainActivity
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            email = extras.getString("email");
            role = extras.getString("role");

            // Set email
            emailEditText.setText(email);
            emailEditText.setEnabled(false); // Disable editing

            // Set role
            TextInputEditText roleEditText = findViewById(R.id.role);
            roleEditText.setText(role);
            roleEditText.setEnabled(false); // Disable editing

            // Check if the role is "student" to determine the visibility of the roll number field
            if ("student".equals(role)) {
                rollNumberLayout.setVisibility(View.VISIBLE);
            } else {
                rollNumberLayout.setVisibility(View.GONE);
            }

            // Set other data if available
            String name = extras.getString("name");
            if (name != null) {
                nameEditText.setText(name);
            }

            String dob = extras.getString("dob");
            if (dob != null) {
                dobEditText.setText(dob);
            }

            String rollNumber = extras.getString("rollNumber");
            if (rollNumber != null) {
                rollNumberEditText.setText(rollNumber);
            }

            String phone = extras.getString("phone");
            if (phone != null) {
                phoneEditText.setText(phone);
            }
        }

        // Set onClickListener for save button
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSaveClicked();
            }
        });

        // Set onClickListener for cancel button
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onCancelClicked();
            }
        });
    }

    public void showDatePickerDialog(View v) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String dob = dayOfMonth + "/" + (month + 1) + "/" + year;
                        dobEditText.setText(dob);
                    }
                }, year, month, dayOfMonth);
        datePickerDialog.show();
    }

    private void onSaveClicked() {

        // Get the values entered by the user
        String name = nameEditText.getText().toString().trim();
        String dob = dobEditText.getText().toString().trim();
        String rollNumber = rollNumberEditText.getText().toString().trim();
        String phone = phoneEditText.getText().toString().trim();
        String saveRole = role; // Use the saved role value here

        // Create a map to store user data
        Map<String, Object> userData = new HashMap<>();
        userData.put("email", email);
        userData.put("role", saveRole); // Use the saved role value here

        // Add name, dob, rollNumber, and phone if not empty
        if (!name.isEmpty()) {
            userData.put("name", name);
        }

        if (!dob.isEmpty()) {
            userData.put("dob", dob);
        }

        if (!rollNumber.isEmpty()) {
            userData.put("rollNumber", rollNumber);
        }

        if (!phone.isEmpty()) {
            userData.put("phone", phone);
        }

        // Get the current user's ID
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Save user data to Firestore
        FirebaseFirestore.getInstance().collection("users")
                .document(userId)
                .set(userData)
                .addOnSuccessListener(aVoid -> {
                    // Data saved successfully
                    Toast.makeText(ProfileActivity.this, "Profile saved", Toast.LENGTH_SHORT).show();
                    // Redirect to main activity
                    startActivity(new Intent(ProfileActivity.this, MainActivity.class));
                    finish(); // Close current activity
                })
                .addOnFailureListener(e -> {
                    // Handle failure
                    Toast.makeText(ProfileActivity.this, "Failed to save profile", Toast.LENGTH_SHORT).show();
                });
    }


    private void onCancelClicked() {
        // Redirect to main activity
        startActivity(new Intent(ProfileActivity.this, MainActivity.class));
        finish(); // Close current activity
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        // Navigate back to MainActivity
        startActivity(new Intent(ProfileActivity.this, MainActivity.class));
        finish(); // Close current activity
    }
}
